Eraser Bot Frontend v1.3 
Created by Seth Ballantyne <seth.ballantyne@gmail.com>

-----------------------------------------------------------------------------------------------------
Whats new in v1.3:
+ The map selection GUI has changed slightly. Checkboxes are now used within the tree view to allow
  users to select multiple maps at once; this design rendered the "add all" button obsolete, so it
  was removed.

+ Tooltips were added to explain what various aspects of the GUI do.

+ EBF will now attempt to automatically detect Eraser bot when setting the path for Quake II.

+ Updated the URL in the about box to point to the github page.

+ EBF now attempts to filter out weapon skins so they're not displayed in the list of available
  skins for any given model.

+ Fixed a bug where changing the paths for Quake II and Eraser caused an exception to be thrown.
----------------------------------------------------------------------------------------------------

Eraser Bot Frontend (EBF) is a front end for Quake II's eraser bot. It's written in C#, targeting .NET 2.0. 
EBF is free, open source software released under the MIT license; for the latest version of the software
and source code, visit https://github.com/sethballantyne/eraser-bot-frontend.

If you don't already have eraser bot installed, unpack and install the contents of eraser.zip to your Quake II directory. 
You'll also need the kw skin pack, otherwise bots in team-based games won't be appear as they should; females appear 
as males, yada yada.

Both eraser bot and the kw skin pack are not mine. Just want to make that clear.

Comments, suggestions, questions or bugs send to <seth.ballantyne@gmail.com>

Have fun!

- Seth.

