Eraser Bot Frontend v1.2 
Created by Seth Ballantyne <seth.ballantyne@gmail.com>

Eraser Bot Frontend (EBF) is a front end for Quake II's eraser bot.
It's written in C#, targeting .NET 2.0. EBF is free, open source software
released under the MIT license; for the latest version of the software
and source code, visit https://github.com/sethballantyne/eraser-bot-frontend.

If you don't already have eraser bot installed, unpack and install the contents
of eraser.zip. You'll also need the kw skin pack, otherwise bots in team-based 
games won't be appear as they should; females appear as males, yada yada.

Both eraser bot and the kw skin pack are not mine. Just want to make that clear.

Comments, suggestions, questions or bugs send to <seth.ballantyne@gmail.com>

Have fun!

- Seth.

